@echo off
setlocal
title Escape the Police: Cyber Pursuit
color 0b

echo ============================================================
echo   ESCAPE THE POLICE: CYBER PURSUIT - PORTABLE EDITION
echo ============================================================
echo.
echo   Sedang membuka game di komputer Anda...
echo.

set "GAME_DIR=%~dp0"
set "HTML_FILE=%GAME_DIR%index.html"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$port = 32800 + (Get-Random -Maximum 5000); ^
   $dir = '%GAME_DIR%'; ^
   $listener = New-Object System.Net.HttpListener; ^
   $listener.Prefixes.Add('http://127.0.0.1:' + $port + '/'); ^
   $listener.Start(); ^
   $url = 'http://127.0.0.1:' + $port + '/index.html'; ^
   $edge32 = \"${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe\"; ^
   $edge64 = \"$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe\"; ^
   $chrome = \"$env:ProgramFiles\Google\Chrome\Application\chrome.exe\"; ^
   $chrome32 = \"${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe\"; ^
   if (Test-Path $edge32) { Start-Process $edge32 -ArgumentList \"--app=$url\" } ^
   elseif (Test-Path $edge64) { Start-Process $edge64 -ArgumentList \"--app=$url\" } ^
   elseif (Test-Path $chrome) { Start-Process $chrome -ArgumentList \"--app=$url\" } ^
   elseif (Test-Path $chrome32) { Start-Process $chrome32 -ArgumentList \"--app=$url\" } ^
   else { Start-Process $url }; ^
   Write-Host 'Game aktif! Biarkan jendela ini terbuka selama bermain.'; ^
   while ($listener.IsListening) { ^
     $context = $listener.GetContext(); ^
     $req = $context.Request; ^
     $res = $context.Response; ^
     $path = $req.Url.LocalPath.TrimStart('/'); ^
     if (-not $path) { $path = 'index.html' }; ^
     $filePath = Join-Path $dir $path; ^
     if (Test-Path $filePath) { ^
       $bytes = [System.IO.File]::ReadAllBytes($filePath); ^
       $ext = [System.IO.Path]::GetExtension($filePath).ToLower(); ^
       $ct = 'application/octet-stream'; ^
       if ($ext -eq '.html') { $ct = 'text/html; charset=utf-8' } ^
       elseif ($ext -eq '.js') { $ct = 'application/javascript; charset=utf-8' } ^
       elseif ($ext -eq '.css') { $ct = 'text/css; charset=utf-8' } ^
       elseif ($ext -eq '.png') { $ct = 'image/png' } ^
       elseif ($ext -eq '.jpg' -or $ext -eq '.jpeg') { $ct = 'image/jpeg' } ^
       elseif ($ext -eq '.ico') { $ct = 'image/x-icon' } ^
       elseif ($ext -eq '.svg') { $ct = 'image/svg+xml' } ^
       elseif ($ext -eq '.json') { $ct = 'application/json' }; ^
       $res.ContentType = $ct; ^
       $res.ContentLength64 = $bytes.Length; ^
       $res.OutputStream.Write($bytes, 0, $bytes.Length); ^
     } else { ^
       $res.StatusCode = 404; ^
     }; ^
     $res.OutputStream.Close(); ^
   }"

if errorlevel 1 (
    echo Membuka langsung via browser...
    start "" "%HTML_FILE%"
)
