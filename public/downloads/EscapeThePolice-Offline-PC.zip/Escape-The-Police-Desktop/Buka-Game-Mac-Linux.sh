#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "Membuka Escape the Police: Cyber Pursuit..."
if which open > /dev/null 2>&1; then
    open "$DIR/index.html"
elif which xdg-open > /dev/null 2>&1; then
    xdg-open "$DIR/index.html"
else
    python3 -m http.server 8080 --directory "$DIR" &
    sleep 1
    if which xdg-open > /dev/null 2>&1; then
        xdg-open "http://localhost:8080"
    fi
fi
