/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-53feb3a3'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "0bab9cd96b6167b3ec9991d057b87af5"
  }, {
    "url": "pwa-512x512.png",
    "revision": "04bea31d1f153f52c27b0e313d6dbe78"
  }, {
    "url": "pwa-192x192.png",
    "revision": "d6c94568305c2f38c00773a023f111b8"
  }, {
    "url": "manifest.json",
    "revision": "b1754a6143bcd2475b396e7839c55990"
  }, {
    "url": "index.html",
    "revision": "1d375514264d8bb5d6fbc9775e82c9fd"
  }, {
    "url": "favicon.ico",
    "revision": "a8f9056daaf74db6ec84d0d3f2ca3736"
  }, {
    "url": "cyberpunk_lobby_bg.jpg",
    "revision": "2298439495c475983c31a8ce4523a8e2"
  }, {
    "url": "cyber_pursuit_logo.jpg",
    "revision": "d31ad4733c66581b5123e05e2f2f7911"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fb3dfb1c250cb1d1d5ab228cb399463a"
  }, {
    "url": "maps/salju.jpg",
    "revision": "b96da902c1aa4c69a01eeb2a4e46c352"
  }, {
    "url": "maps/pegunungan.jpg",
    "revision": "b3f6a1660e5990cfdc15bc61ac7167f1"
  }, {
    "url": "maps/padang_pasir.jpg",
    "revision": "71836f4e73b48caf6ad557f2e20a07e2"
  }, {
    "url": "maps/kota.jpg",
    "revision": "9db791af9cb6670be12a69562c4fe0b4"
  }, {
    "url": "maps/hutan.jpg",
    "revision": "aca7b6b5ac25d968bf547719c6d655d3"
  }, {
    "url": "difficulties/sulit.jpg",
    "revision": "f13c92ed1851d91c92199d177a3e8af4"
  }, {
    "url": "difficulties/santai.jpg",
    "revision": "6be6379d294c716b39b0ae8b55ea9c7f"
  }, {
    "url": "difficulties/normal.jpg",
    "revision": "e64049b4340f94390ecba78e31df78ef"
  }, {
    "url": "difficulties/maxxx.jpg",
    "revision": "0793bbd13bbada8cdf15461f2dc8cdfe"
  }, {
    "url": "assets/workbox-window.prod.es5-BBnX5xw4.js",
    "revision": null
  }, {
    "url": "assets/police_busted_bg.jpg",
    "revision": null
  }, {
    "url": "assets/index-DxwVxCBK.js",
    "revision": null
  }, {
    "url": "assets/index-CmS4LGrl.css",
    "revision": null
  }, {
    "url": "assets/garage_cyber_hangar.jpg",
    "revision": null
  }, {
    "url": "assets/cyberpunk_police_roadblock.jpg",
    "revision": null
  }, {
    "url": "assets/bundler-Cs8hR61n.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fb3dfb1c250cb1d1d5ab228cb399463a"
  }, {
    "url": "cyber_pursuit_logo.jpg",
    "revision": "d31ad4733c66581b5123e05e2f2f7911"
  }, {
    "url": "favicon.ico",
    "revision": "a8f9056daaf74db6ec84d0d3f2ca3736"
  }, {
    "url": "pwa-192x192.png",
    "revision": "d6c94568305c2f38c00773a023f111b8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "04bea31d1f153f52c27b0e313d6dbe78"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0bab9cd96b6167b3ec9991d057b87af5"
  }, {
    "url": "manifest.webmanifest",
    "revision": "a66b8e147db09035bd57bf87f22fc5b8"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/\.(?:png|jpg|jpeg|svg|gif|webp|ico)$/i, new workbox.StaleWhileRevalidate({
    "cacheName": "game-assets-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^\/api\/.*$/i, new workbox.NetworkFirst({
    "cacheName": "api-cache",
    "networkTimeoutSeconds": 2,
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 86400
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
